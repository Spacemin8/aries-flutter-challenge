package com.example.flutter_challenge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
